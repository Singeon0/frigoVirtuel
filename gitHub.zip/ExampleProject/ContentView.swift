//
//  ContentView.swift
//  frigoVirtuel
//
//  Created by MacBook d'Arthur on 13/05/2022.
//

import SwiftUI

// variables global
 // liste des codes bars référencés
// dictionnaire de produits avec leur code bar comme clé


let defaults = UserDefaults.standard
var codeBar: [Int] = [66, 88, 99, 101]
var produits: [Produit] = []

//defaults.set(codeBar, forKey: "codeBar")
//defaults.set(produits, forKey: "produits")

struct ContentView: View {
    @State var showingScanner = false
    @State var barcodeValue = ""
    
    
    var body: some View {
        VStack{
            
            Spacer()
            
            Button("Scanner") {
                //codeBar = defaults.object(forKey: "codeBar") as? [Int] ?? [Int]()
                
                
                
                if let data = UserDefaults.standard.data(forKey: "produits") {
                    do {
                        // Create JSON Decoder
                        let decoder = JSONDecoder()

                        // Decode Note
                        produits = try decoder.decode([Produit].self, from: data)

                    } catch {
                        print("Unable to Decode Notes (\(error))")
                    }
                }
                
                print(produits)
                
                self.showingScanner = true
            } .sheet(isPresented: self.$showingScanner) {
                ModalScannerView(barcodeValue: self.$barcodeValue, openFirst: self.showingScanner, torchIsOn: false)
            }
            .position(x: 100, y: 100)

            Text(String(codeBar[codeBar.count-1]))
                .position(x: 100, y: 150)
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .padding()
    }
}
