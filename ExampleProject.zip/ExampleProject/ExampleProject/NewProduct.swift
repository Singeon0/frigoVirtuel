//
//  newProduct.swift
//  ExampleProject
//
//  Created by MacBook d'Arthur on 13/05/2022.
//  Copyright © 2022 narongrit kanhanoi. All rights reserved.
//

import SwiftUI

struct newProduct: View {
    @State var nom: String
    @State var type: String
    @State var qtt: String
    @State var peremp = Date()
    @Environment(\.presentationMode) var presentationMode // permet de fermer la fenêtre quand le bouton "Enregistrer est cliquer"
    var code = codeBar[codeBar.count-1]

    
    var body: some View {
        VStack {
            TextField("Nom", text: $nom)
            TextField("type", text: $type)
            TextField("Quantité", text: $qtt)
            DatePicker(
                    "Date de péremption",
                    selection: $peremp,
                    displayedComponents: [.date]
                )
            Spacer()
            
            //Text(String(code)) // le code bar du nouveau produit est le dernier que j'ai ajouté dans mes codes bar référencés
            
            Spacer()
            
            Button("Enregistrer ce nouveau produit") {
                let newProd = Produit(id: self.nom, type: self.type, quantite: Int(self.qtt) ?? 1, peremp: self.peremp)
                produits.append(newProd)
                
//                do {
//                    // Create JSON Encoder
//                    let encoder = JSONEncoder()
//
//                    // Encode Note
//                    let data = try encoder.encode(produits)
//
//                    // Write/Set Data
//                    UserDefaults.standard.set(data, forKey: "produits")
//
//                } catch {
//                    print("Unable to Encode Array of Notes (\(error))")
//                }
                
                
                
                
                
                
                presentationMode.wrappedValue.dismiss()
                
            }
        }
    }
}

struct newProduct_Previews: PreviewProvider {
    static var previews: some View {
        newProduct(nom: "Nom…", type: "Type…", qtt: "Quantité…", peremp: Date())
            .padding()
    }
}

