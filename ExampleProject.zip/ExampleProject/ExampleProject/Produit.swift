//
//  produits.swift
//  ExampleProject
//
//  Created by MacBook d'Arthur on 13/05/2022.
//  Copyright © 2022 narongrit kanhanoi. All rights reserved.
//

import Foundation

struct Produit: Codable, Identifiable {
    var id, type: String
    var quantite : Int
    var peremp = Date()
    
    func getNom() -> String {
        return self.id
    }

    func getType() -> String {
        return self.type
    }

    func getPeremp() -> Date {
        return self.peremp
    }
}


